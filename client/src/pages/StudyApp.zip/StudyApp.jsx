import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { readOfflineCache, writeOfflineCache } from '../utils/offlineCache';
import { questionAPI, syllabusAPI, subjectAPI } from '../utils/api';
import MathText from '../components/MathText';
import ExplanationBox from '../components/ExplanationBox';
import { FreeTrialPaywall } from './PracticeMode';

const API = '/api';
const LETTERS = ['A','B','C','D','E'];

function safeParseArray(v) {
  if (Array.isArray(v)) return v;
  if (!v) return [];
  try { const p = JSON.parse(v); return Array.isArray(p)?p:[]; } catch { return []; }
}

function formatTime(s) {
  const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
  if (h>0) return `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
  return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
}

// Mobile gets a purpose-built layout (see MobileExamScreen below), desktop keeps
// the existing sidebar-based one — this just decides which to render.
function useIsMobile() {
  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth <= 768);
  useEffect(() => {
    const onResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return isMobile;
}

// ── EXAM TYPES & SUBJECTS ─────────────────────────────────────
// Only used as a fallback now if the live exam_bodies fetch fails — see
// SetupScreen below, which normally loads this list from the server so
// admin-added exam bodies (e.g. a university's own entrance exam) show up
// here without a code change.
const FALLBACK_EXAM_TYPES = ['JAMB','WAEC','NECO','NABTEB','POST_UTME','CUSTOM'];
// Only used as a fallback if the live subjects fetch fails — see
// SetupScreen below, which normally loads this list from the server so
// admin-added subjects (e.g. a university's own "GS COURSE 101" or
// "MATHS101") show up here without a code change.
const FALLBACK_SUBJECTS = [
  'Mathematics','English Language','Physics','Chemistry','Biology',
  'Economics','Government','Literature in English','Geography',
  'Computer Studies','Accounting','Agricultural Science',
  'Civic Education','Commerce','Further Mathematics',
  'Technical Drawing','Islamic Studies','Christian Religious Studies',
];
// Generated rather than hand-typed, and starting from 1980 rather than 2005 —
// WAEC/JAMB/NECO past questions commonly go back decades further than a
// hardcoded recent-years list assumes (this is what was hiding the WAEC 1988
// import: the year simply wasn't a selectable option).
const YEARS = ['All Years', ...Array.from({ length: new Date().getFullYear() - 1980 + 1 }, (_, i) => String(new Date().getFullYear() - i))];

// ── SETUP SCREEN ──────────────────────────────────────────────
function SetupScreen({ onStart }) {
  const [searchParams] = useSearchParams();
  const [examType,  setExamType]  = useState('WAEC');
  const [subject,   setSubject]   = useState(searchParams.get('subject') || 'Mathematics');
  const [year,      setYear]      = useState('All Years');
  const [count,     setCount]     = useState(60);
  const [duration,  setDuration]  = useState(120);
  const [mode,      setMode]      = useState('mock'); // mock | practice | study
  const [shuffle,   setShuffle]   = useState(true);
  const [showInfo,  setShowInfo]  = useState(false);

  // Was a fixed 6-button list — an exam body added in the admin's Exam Body
  // Manager (a university's own entrance exam, for instance) had no way to
  // ever show up here, since this page never asked the server what exists.
  // Now it reads from the same exam_bodies table Exam Body Manager and the
  // Import page's dropdown already use — add one there (or from Import's
  // own "+ Add new exam body" shortcut) and it appears here automatically,
  // no code change needed. Falls back to the original hardcoded list only
  // if the fetch itself fails, so this never regresses to a blank screen.
  const [examTypes, setExamTypes] = useState(FALLBACK_EXAM_TYPES);
  useEffect(() => {
    syllabusAPI.examBodies()
      .then(r => {
        const bodies = (r.data.exam_bodies || []).map(b => b.code).filter(Boolean);
        // CUSTOM ("General practice, not tied to one exam body") is a
        // client-side concept, not a real exam_bodies row — always keep it
        // available alongside whatever the admin has added.
        setExamTypes(bodies.length ? [...bodies, 'CUSTOM'] : FALLBACK_EXAM_TYPES);
      })
      .catch(() => setExamTypes(FALLBACK_EXAM_TYPES));
  }, []);

  // Same fix, same reason — subjects only ever came from a hardcoded list
  // here, so a subject the admin added specifically for a university course
  // (see the Subjects admin page) had no path to ever appear as an option.
  const [subjects, setSubjects] = useState(FALLBACK_SUBJECTS);
  useEffect(() => {
    subjectAPI.list()
      .then(r => {
        const names = (r.data.subjects || []).map(s => s.name).filter(Boolean);
        setSubjects(names.length ? names : FALLBACK_SUBJECTS);
      })
      .catch(() => setSubjects(FALLBACK_SUBJECTS));
  }, []);

  const EXAM_COLOR_PALETTE = ['#2563EB','#16A34A','#D97706','#DC2626','#7C3AED','#0891B2','#DB2777','#65A30D'];
  const examColors = { CUSTOM: '#6366F1' };
  examTypes.forEach((e, i) => { if (!examColors[e]) examColors[e] = EXAM_COLOR_PALETTE[i % EXAM_COLOR_PALETTE.length]; });

  return (
    <div style={{ minHeight:'100dvh', background:'#F0F4F8', fontFamily:"'Inter',sans-serif" }}>
      {/* Header */}
      <div style={{ background:'#1E3A5F', padding:'12px 24px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:36, height:36, borderRadius:8, background:'linear-gradient(135deg,#6366F1,#818CF8)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, fontWeight:900, color:'#fff' }}>E</div>
          <div>
            <div style={{ color:'#fff', fontWeight:800, fontSize:16 }}>ExamOS Practice</div>
            <div style={{ color:'rgba(255,255,255,0.6)', fontSize:11 }}>JAMB · WAEC · NECO · POST-UTME</div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth:800, margin:'0 auto', padding:'32px 16px' }}>
        <h1 style={{ fontSize:'1.6rem', fontWeight:800, color:'#1E3A5F', marginBottom:6 }}>Configure Practice Session</h1>
        <p style={{ color:'#64748B', fontSize:14, marginBottom:28 }}>Select your exam, subject, and preferences below</p>

        {/* Exam type */}
        <div style={{ background:'#fff', borderRadius:12, padding:'20px', marginBottom:16, boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize:11, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:12 }}>Exam Type</div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
            {examTypes.map(e => (
              <button key={e} onClick={() => setExamType(e)} style={{
                padding:'8px 18px', borderRadius:20, border:`2px solid ${examType===e ? examColors[e] : '#E2E8F0'}`,
                background: examType===e ? examColors[e] : '#F8FAFC',
                color: examType===e ? '#fff' : '#475569',
                fontWeight:700, fontSize:13, cursor:'pointer', transition:'all 0.15s',
                fontFamily:"'Inter',sans-serif",
              }}>{e}</button>
            ))}
          </div>
        </div>

        {/* Subject + Year */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:16 }}>
          <div style={{ background:'#fff', borderRadius:12, padding:'20px', boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>Subject</div>
            <select value={subject} onChange={e => setSubject(e.target.value)} style={{ width:'100%', padding:'10px 12px', borderRadius:8, border:'1.5px solid #E2E8F0', background:'#F8FAFC', color:'#1E293B', fontFamily:"'Inter',sans-serif", fontSize:14, cursor:'pointer' }}>
              {subjects.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div style={{ background:'#fff', borderRadius:12, padding:'20px', boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>Year</div>
            <select value={year} onChange={e => setYear(e.target.value)} style={{ width:'100%', padding:'10px 12px', borderRadius:8, border:'1.5px solid #E2E8F0', background:'#F8FAFC', color:'#1E293B', fontFamily:"'Inter',sans-serif", fontSize:14, cursor:'pointer' }}>
              {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        </div>

        {/* Questions + Duration */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:16 }}>
          <div style={{ background:'#fff', borderRadius:12, padding:'20px', boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>No. of Questions</div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
              {[10,20,40,60,80,100].map(n => (
                <button key={n} onClick={() => setCount(n)} style={{ padding:'7px 14px', borderRadius:8, border:`2px solid ${count===n?'#2563EB':'#E2E8F0'}`, background:count===n?'#EFF6FF':'#F8FAFC', color:count===n?'#2563EB':'#64748B', fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:"'Inter',sans-serif", transition:'all 0.12s' }}>{n}</button>
              ))}
            </div>
          </div>
          <div style={{ background:'#fff', borderRadius:12, padding:'20px', boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10 }}>Duration (minutes)</div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
              {[15,30,60,90,120,180].map(d => (
                <button key={d} onClick={() => setDuration(d)} style={{ padding:'7px 14px', borderRadius:8, border:`2px solid ${duration===d?'#2563EB':'#E2E8F0'}`, background:duration===d?'#EFF6FF':'#F8FAFC', color:duration===d?'#2563EB':'#64748B', fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:"'Inter',sans-serif", transition:'all 0.12s' }}>{d}</button>
              ))}
            </div>
          </div>
        </div>

        {/* Mode */}
        <div style={{ background:'#fff', borderRadius:12, padding:'20px', marginBottom:16, boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
          <div style={{ fontSize:11, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:12 }}>Select Mode</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10 }}>
            {[
              { id:'mock',     icon:'📝', label:'Mock Exam',   desc:'Timed, no hints, review at end' },
              { id:'practice', icon:'✏️',  label:'Practice',   desc:'See correct answer immediately' },
              { id:'study',    icon:'📖', label:'Study Mode',  desc:'With explanations, no timer' },
              { id:'adaptive', icon:'🎯', label:'Adaptive AI', desc:'Difficulty adjusts to how you do' },
            ].map(m => (
              <button key={m.id} onClick={() => setMode(m.id)} style={{
                padding:'14px 12px', borderRadius:10,
                border:`2px solid ${mode===m.id?'#2563EB':'#E2E8F0'}`,
                background:mode===m.id?'#EFF6FF':'#F8FAFC',
                cursor:'pointer', textAlign:'center', fontFamily:"'Inter',sans-serif",
                transition:'all 0.12s',
              }}>
                <div style={{ fontSize:24, marginBottom:6 }}>{m.icon}</div>
                <div style={{ fontWeight:700, fontSize:13, color:mode===m.id?'#2563EB':'#1E293B', marginBottom:3 }}>{m.label}</div>
                <div style={{ fontSize:11, color:'#94A3B8', lineHeight:1.4 }}>{m.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Options row */}
        <div style={{ background:'#fff', borderRadius:12, padding:'16px 20px', marginBottom:16, boxShadow:'0 1px 4px rgba(0,0,0,0.08)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div style={{ fontSize:13, fontWeight:600, color:'#1E293B' }}>Shuffle Questions</div>
          <div onClick={() => setShuffle(s=>!s)} style={{ width:44, height:24, borderRadius:12, background:shuffle?'#2563EB':'#CBD5E1', position:'relative', cursor:'pointer', transition:'background 0.2s', flexShrink:0 }}>
            <div style={{ position:'absolute', top:2, left:shuffle?22:2, width:20, height:20, borderRadius:'50%', background:'#fff', transition:'left 0.2s', boxShadow:'0 1px 4px rgba(0,0,0,0.2)' }}/>
          </div>
        </div>

        {/* Instructions */}
        <div style={{ background:'#fff', borderRadius:12, overflow:'hidden', marginBottom:24, boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
          <button onClick={() => setShowInfo(s=>!s)} style={{ width:'100%', padding:'14px 20px', background:'none', border:'none', cursor:'pointer', display:'flex', justifyContent:'space-between', alignItems:'center', fontFamily:"'Inter',sans-serif" }}>
            <span style={{ fontSize:13, fontWeight:700, color:'#1E3A5F' }}>📋 Instructions</span>
            <span style={{ fontSize:12, color:'#94A3B8', transform:showInfo?'rotate(180deg)':'none', transition:'transform 0.2s' }}>▼</span>
          </button>
          {showInfo && (
            <div style={{ padding:'0 20px 16px', fontSize:13, color:'#475569', lineHeight:1.9, borderTop:'1px solid #F1F5F9' }}>
              <ul style={{ paddingLeft:18, marginTop:12 }}>
                <li>Use the question palette on the left to jump to any question.</li>
                <li>Click a radio button to select your answer.</li>
                <li>In <b>Practice mode</b>, the correct answer shows immediately after selection.</li>
                <li>In <b>Mock Exam</b> mode, answers are revealed only after submission.</li>
                <li>In <b>Study mode</b>, full explanations are shown with each answer.</li>
                <li>Use the Bookmark button to flag questions for review.</li>
                <li>The calculator is available at all times in the toolbar.</li>
                <li>Submit before the timer expires to save your score.</li>
              </ul>
            </div>
          )}
        </div>

        {/* Summary + Start */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
          <div style={{ background:'#1E3A5F', borderRadius:12, padding:'18px 20px', color:'#fff' }}>
            <div style={{ fontSize:12, fontWeight:700, opacity:0.6, textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:12 }}>Session Summary</div>
            {[['Exam',examType],['Subject',subject],['Year',year],['Questions',count],['Duration',`${duration} min`],['Mode',mode.charAt(0).toUpperCase()+mode.slice(1)]].map(([k,v])=>(
              <div key={k} style={{ display:'flex', justifyContent:'space-between', fontSize:12, padding:'5px 0', borderBottom:'1px solid rgba(255,255,255,0.1)' }}>
                <span style={{ opacity:0.6 }}>{k}</span><span style={{ fontWeight:700 }}>{v}</span>
              </div>
            ))}
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <button onClick={() => onStart({ examType, subject, year, count, duration, mode, shuffle })}
              style={{ flex:1, background:'linear-gradient(135deg,#2563EB,#1D4ED8)', color:'#fff', border:'none', borderRadius:12, fontSize:16, fontWeight:800, cursor:'pointer', fontFamily:"'Inter',sans-serif", padding:'0 20px', boxShadow:'0 4px 16px rgba(37,99,235,0.3)', transition:'all 0.15s' }}
              onMouseOver={e => e.currentTarget.style.transform='translateY(-2px)'}
              onMouseOut={e => e.currentTarget.style.transform=''}
            >
              🚀 Start Session<br/><span style={{ fontSize:12, opacity:0.8, fontWeight:500 }}>{count} questions · {duration} min</span>
            </button>
            <SaveOfflineButton config={{ examType, subject, year, count }} />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── SAVE FOR OFFLINE ─────────────────────────────────────────
function SaveOfflineButton({ config }) {
  const [state, setState] = useState('idle'); // idle | saving | explaining | saved | error | already
  const [explainProgress, setExplainProgress] = useState(null); // { done, total }

  useEffect(() => {
    const key = `examos-offline-qset:${config.subject}:${config.examType}:${config.year}`;
    setState(readOfflineCache(key)?.length ? 'already' : 'idle');
  }, [config.subject, config.examType, config.year]);

  const handleSave = async () => {
    if (!navigator.onLine) return setState('error');
    setState('saving');
    try {
      const params = { limit: config.count };
      if (config.subject !== 'All') params.subject = config.subject;
      if (config.examType !== 'CUSTOM') params.exam_type = config.examType;
      if (config.year !== 'All Years') params.year = config.year;
      const res = await axios.get(`${API}/questions`, { params });
      const qs = (res.data.questions || []).map(q => ({ ...q, options: safeParseArray(q.options) }));
      if (!qs.length) return setState('error');

      // The whole point of "save for offline" is being able to study with
      // no connection at all — including reading the explanation for
      // whichever answer you got wrong. A question that had never been
      // opened by anyone before had no explanation generated yet, and once
      // actually offline there'd be no network left to fetch one. So before
      // finishing the save, fill in any still-missing explanations now,
      // while there's still a connection to do it with.
      const missing = qs.filter(q => !q.explanation);
      if (missing.length) {
        setState('explaining');
        setExplainProgress({ done: 0, total: missing.length });
        for (let i = 0; i < missing.length; i++) {
          try {
            const r = await questionAPI.generateExplanation(missing[i].id);
            missing[i].explanation = r.data?.explanation || '';
          } catch (e) {
            // A quota-exhausted or otherwise failed explanation shouldn't
            // block saving the rest of the set for offline use — this
            // question just won't have one until a later save/backfill.
            if (e.response?.data?.code === 'AI_QUOTA_EXCEEDED') break; // no point continuing this run
          }
          setExplainProgress({ done: i + 1, total: missing.length });
        }
      }

      const key = `examos-offline-qset:${config.subject}:${config.examType}:${config.year}`;
      writeOfflineCache(key, qs);
      setState('saved');
    } catch { setState('error'); }
  };

  const labels = {
    idle:      { text: '📥 Save for Offline', bg:'#fff', color:'#2563EB', border:'2px solid #2563EB' },
    saving:    { text: '⏳ Saving…',           bg:'#fff', color:'#94A3B8', border:'2px solid #E2E8F0' },
    explaining:{ text: explainProgress ? `⏳ Preparing explanations… ${explainProgress.done}/${explainProgress.total}` : '⏳ Preparing explanations…', bg:'#fff', color:'#94A3B8', border:'2px solid #E2E8F0' },
    saved:     { text: '✅ Saved for Offline', bg:'#ECFDF5', color:'#16A34A', border:'2px solid #16A34A' },
    already:   { text: '✅ Already Saved · Tap to Refresh', bg:'#ECFDF5', color:'#16A34A', border:'2px solid #16A34A' },
    error:     { text: '⚠️ Couldn\'t save — check connection', bg:'#FEF2F2', color:'#DC2626', border:'2px solid #FCA5A5' },
  };
  const l = labels[state];
  const busy = state === 'saving' || state === 'explaining';

  return (
    <button
      onClick={handleSave}
      disabled={busy}
      style={{
        padding:'12px 16px', borderRadius:10, fontSize:13, fontWeight:700,
        cursor: busy ? 'default' : 'pointer',
        fontFamily:"'Inter',sans-serif", transition:'all 0.15s',
        background:l.bg, color:l.color, border:l.border,
      }}
    >
      {l.text}
      <div style={{ fontSize:10.5, fontWeight:500, opacity:0.75, marginTop:2 }}>
        Practice offline later on this subject, even with no connection — every question comes with its full explanation, ready with no signal needed
      </div>
    </button>
  );
}

// ── CALCULATOR ────────────────────────────────────────────────
function SimpleCalc({ onClose }) {
  const [display, setDisplay] = useState('0');
  const [prev, setPrev] = useState(null);
  const [op, setOp] = useState(null);
  const [fresh, setFresh] = useState(false);

  const press = (val) => {
    if (val==='C') { setDisplay('0'); setPrev(null); setOp(null); setFresh(false); return; }
    if (val==='⌫') { setDisplay(d=>d.length>1?d.slice(0,-1):'0'); return; }
    if (['+','-','×','÷'].includes(val)) {
      setPrev(display); setOp(val); setFresh(true); return;
    }
    if (val==='=') {
      if (!op||!prev) return;
      const a=parseFloat(prev), b=parseFloat(display);
      const res = op==='+'?a+b:op==='-'?a-b:op==='×'?a*b:b===0?'Error':a/b;
      setDisplay(String(parseFloat(res.toPrecision(10)))); setPrev(null); setOp(null); setFresh(false); return;
    }
    if (val==='.') { if (!display.includes('.')) setDisplay(d=>d+'.'); return; }
    if (fresh||display==='0') { setDisplay(val); setFresh(false); }
    else { if (display.replace('-','').replace('.','').length<12) setDisplay(d=>d+val); }
  };

  const rows=[['C','⌫','%','÷'],['7','8','9','×'],['4','5','6','-'],['1','2','3','+'],['.','0','=','=']];
  return (
    <div style={{ position:'fixed', bottom:80, right:20, width:220, background:'#1C1C1E', borderRadius:16, boxShadow:'0 20px 60px rgba(0,0,0,0.5)', border:'1px solid rgba(255,255,255,0.1)', overflow:'hidden', zIndex:9999, fontFamily:'system-ui' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 14px 4px' }}>
        <span style={{ fontSize:11, color:'rgba(255,255,255,0.4)', fontWeight:700 }}>CALC</span>
        <button onClick={onClose} style={{ background:'#FF5F57', border:'none', borderRadius:'50%', width:13, height:13, cursor:'pointer', fontSize:0 }}/>
      </div>
      <div style={{ textAlign:'right', fontSize:display.length>8?26:34, fontWeight:300, color:'#fff', padding:'4px 16px 10px', minHeight:50, lineHeight:1 }}>{display}</div>
      <div style={{ padding:'0 8px 10px' }}>
        {rows.map((row,ri) => (
          <div key={ri} style={{ display:'flex', gap:6, marginBottom:6 }}>
            {row.map((btn,bi) => {
              if (ri===4&&bi===2&&btn==='=') return null;
              const isOp = ['+','-','×','÷','='].includes(btn);
              const isGray = ['C','⌫','%'].includes(btn);
              const wide = ri===4&&bi===2;
              return (
                <button key={bi} onClick={() => press(btn)} style={{
                  flex: wide?2:1, height:44, borderRadius:9, border:'none', cursor:'pointer',
                  background:isOp?'#FF9F0A':isGray?'#636366':'#2C2C2E',
                  color:isGray?'#000':'#fff', fontSize:17, fontWeight:400, transition:'opacity 0.1s',
                  fontFamily:'system-ui',
                }}
                  onMouseDown={e=>e.currentTarget.style.opacity='0.7'}
                  onMouseUp={e=>e.currentTarget.style.opacity='1'}
                >{btn}</button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── MAIN EXAM SCREEN (ExamGuide style) ───────────────────────
function ExamScreen({ config, onFinish }) {
  const [questions,  setQuestions]  = useState([]);
  const [answers,    setAnswers]    = useState({});
  const [revealed,   setRevealed]   = useState({});
  const [bookmarked, setBookmarked] = useState(new Set());
  const [current,    setCurrent]    = useState(0);
  const [timeLeft,   setTimeLeft]   = useState(config.mode==='study' ? 999999 : config.duration * 60);
  const [loading,    setLoading]    = useState(true);
  const [showCalc,   setShowCalc]   = useState(false);
  const [attempts,   setAttempts]   = useState(0);
  const [usingOfflineCache, setUsingOfflineCache] = useState(false);
  const [isOnline,   setIsOnline]   = useState(navigator.onLine);
  const [lowData,    setLowData]    = useState(() => localStorage.getItem('examos-lowdata') === '1');
  const [adaptiveDifficulty, setAdaptiveDifficulty] = useState('medium');
  // Set from the questions fetch when this is a free-trial visitor (see
  // routes/questions.js) — remaining===0 means this batch is the last of
  // their 5 free questions. showPaywall auto-flips true once they've seen
  // the answer to that last question (effect below), same trigger pattern
  // as PracticeMode.jsx's own engine.
  const [freeTrial,  setFreeTrial]  = useState(null);
  const [showPaywall,setShowPaywall]= useState(false);
  const poolRef = useRef({ easy: [], medium: [], hard: [] });
  const adaptedChunksRef = useRef(new Set());
  const ADAPT_CHUNK = 5;
  const timerRef = useRef(null);
  const submittedRef = useRef(false);
  const isMobile = useIsMobile();

  useEffect(() => {
    const goOnline = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);
    window.addEventListener('online', goOnline);
    window.addEventListener('offline', goOffline);
    return () => { window.removeEventListener('online', goOnline); window.removeEventListener('offline', goOffline); };
  }, []);

  const toggleLowData = () => {
    setLowData(v => { localStorage.setItem('examos-lowdata', v ? '0' : '1'); return !v; });
  };

  const cacheKey = `examos-offline-qset:${config.subject}:${config.examType}:${config.year}`;

  useEffect(() => { loadQuestions(); }, []);

  // Same auto-popup pattern as PracticeMode.jsx's engine — once the free
  // trial's last question has its answer revealed, give them a couple
  // seconds to actually read it, then show the paywall right over the
  // session instead of a redirect.
  useEffect(() => {
    if (!freeTrial || freeTrial.remaining > 0) return;
    if (!questions.length) return;
    const lastQ = questions[questions.length - 1];
    if (current !== questions.length - 1 || !revealed[lastQ?.id]) return;
    const t = setTimeout(() => setShowPaywall(true), 2500);
    return () => clearTimeout(t);
  }, [current, revealed, freeTrial, questions]);

  // Adaptive AI: every time the student crosses into a new 5-question chunk
  // for the first time, look at how they did in the chunk just completed and
  // swap the upcoming chunk's questions for easier/harder ones accordingly.
  // Already-visited questions are never touched — only ones ahead, not yet seen.
  useEffect(() => {
    if (config.mode !== 'adaptive' || loading || questions.length === 0) return;
    const chunkIdx = Math.floor(current / ADAPT_CHUNK);
    if (chunkIdx === 0 || adaptedChunksRef.current.has(chunkIdx)) return;
    if (chunkIdx * ADAPT_CHUNK > current) return; // haven't actually reached this chunk yet

    const prevStart = (chunkIdx - 1) * ADAPT_CHUNK;
    const prevEnd = Math.min(chunkIdx * ADAPT_CHUNK, questions.length);
    let correct = 0, answered = 0;
    for (let i = prevStart; i < prevEnd; i++) {
      const q = questions[i];
      const ans = answers[q.id];
      if (!ans) continue;
      answered++;
      const correctSet = safeParseArray(q.correct_answers).map(c => c.toLowerCase().trim());
      if (correctSet.includes(String(ans).toLowerCase().trim())) correct++;
    }

    adaptedChunksRef.current.add(chunkIdx);
    if (answered === 0) return; // nothing answered in that chunk — leave upcoming difficulty as-is

    const accuracy = correct / answered;
    const order = ['easy', 'medium', 'hard'];
    const currentLevel = order.indexOf(adaptiveDifficulty);
    let nextLevel = currentLevel;
    if (accuracy >= 0.75) nextLevel = Math.min(currentLevel + 1, 2);
    else if (accuracy <= 0.4) nextLevel = Math.max(currentLevel - 1, 0);
    const target = order[nextLevel];
    setAdaptiveDifficulty(target);

    const nextStart = chunkIdx * ADAPT_CHUNK;
    const nextEnd = Math.min(nextStart + ADAPT_CHUNK, questions.length);
    const pool = poolRef.current;
    const replacement = [];
    for (let i = nextStart; i < nextEnd; i++) {
      const q = pool[target].pop() || pool.medium.pop() || pool.easy.pop() || pool.hard.pop();
      if (q) replacement.push(q); else replacement.push(questions[i]); // pool exhausted — keep what was there
    }
    setQuestions(prev => {
      const copy = [...prev];
      for (let i = 0; i < replacement.length; i++) copy[nextStart + i] = replacement[i];
      return copy;
    });
  }, [current, loading]);

  useEffect(() => {
    if (loading || config.mode==='study') return;
    timerRef.current = setInterval(() => {
      setTimeLeft(t => { if (t<=1) { clearInterval(timerRef.current); handleSubmit(true); return 0; } return t-1; });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, [loading]);

  const loadQuestions = async () => {
    // Offline: go straight to local cache, skip the network attempt entirely
    if (!navigator.onLine) {
      const cached = readOfflineCache(cacheKey);
      if (cached?.length) {
        let qs = cached;
        if (config.shuffle) qs = [...qs].sort(() => Math.random() - 0.5);
        setQuestions(qs.slice(0, config.count));
        setUsingOfflineCache(true);
        setLoading(false);
        return;
      }
      // Nothing saved for this exact subject/exam/year combo while offline
      setQuestions(makeDemoQuestions(config.subject, config.count));
      setUsingOfflineCache(true);
      setLoading(false);
      return;
    }

    try {
      const params = { limit: config.mode === 'adaptive' ? Math.min(config.count * 3, 240) : config.count };
      if (config.subject !== 'All') params.subject = config.subject;
      if (config.examType !== 'CUSTOM') params.exam_type = config.examType;
      if (config.year !== 'All Years') params.year = config.year;
      const res = await axios.get(`${API}/questions`, { params });
      let qs = (res.data.questions || []).map(q => ({ ...q, options: safeParseArray(q.options) }));

      if (config.mode === 'adaptive' && qs.length > 0) {
        const pool = { easy: [], medium: [], hard: [] };
        qs.forEach(q => { (pool[q.difficulty] || pool.medium).push(q); });
        Object.keys(pool).forEach(k => pool[k].sort(() => Math.random() - 0.5));
        poolRef.current = pool;
        const initial = [];
        for (let i = 0; i < config.count; i++) {
          const q = pool.medium.pop() || pool.easy.pop() || pool.hard.pop();
          if (q) initial.push(q);
        }
        writeOfflineCache(cacheKey, initial);
        setQuestions(initial);
        setLoading(false);
        return;
      }

      if (qs.length === 0) qs = makeDemoQuestions(config.subject, config.count);
      else writeOfflineCache(cacheKey, qs); // silently save for next time we're offline
      if (config.shuffle) qs = qs.sort(() => Math.random() - 0.5);
      setQuestions(qs.slice(0, config.count));
      if (res.data.free_trial) setFreeTrial(res.data.free_trial);
    } catch (err) {
      // Quota already exhausted before this session could even start (e.g.
      // this browser used its 5 free questions in an earlier visit) — show
      // the paywall directly instead of quietly loading demo/cached
      // questions, which would let them "practice" with no real path to
      // upgrade. This is the in-page equivalent of what a global redirect
      // used to try to do (and broke — see main.jsx for why that's gone).
      if (err.response?.status === 402 && err.response?.data?.code === 'FREE_LIMIT_REACHED') {
        setFreeTrial({ remaining: 0, limit: err.response.data.free_limit || 5 });
        setShowPaywall(true);
        setQuestions([]);
      } else {
        // Network call failed even though navigator.onLine said true (flaky connection) — fall back to cache
        const cached = readOfflineCache(cacheKey);
        if (cached?.length) {
          setQuestions(cached.slice(0, config.count));
          setUsingOfflineCache(true);
        } else {
          setQuestions(makeDemoQuestions(config.subject, config.count));
        }
      }
    } finally { setLoading(false); }
  };

  const makeDemoQuestions = (subject, n) => Array.from({length:Math.min(n,5)},(_,i)=>({
    id:`demo-${i}`, question_text:`[Demo] ${subject} Question ${i+1}. Add past questions via Admin → Import Questions.`,
    options:['Option A','Option B','Option C','Option D'], correct_answers:JSON.stringify(['Option A']),
    explanation:'Import real JAMB/WAEC questions via the admin panel.', marks:1,
  }));

  const selectAnswer = (qId, opt) => {
    if (submittedRef.current) return;
    const isNew = answers[qId] !== opt;
    setAnswers(a => ({ ...a, [qId]: opt }));
    if (isNew) setAttempts(a => a+1);
    if (config.mode !== 'mock') setRevealed(r => ({ ...r, [qId]: true }));
  };

  const handleSubmit = useCallback((auto=false) => {
    if (submittedRef.current) return;
    // Catch-all for the free-trial paywall — the per-question effect above
    // only fires once the last question's answer is revealed, which never
    // happens if it was skipped instead of answered (exactly what was
    // happening: Submit went straight through to the results screen with
    // Q5 skipped and the paywall never seen). This guarantees it still
    // appears before results are reachable, answered-out or not.
    if (freeTrial && freeTrial.remaining === 0 && !showPaywall) {
      setShowPaywall(true);
      return;
    }
    submittedRef.current = true;
    clearInterval(timerRef.current);
    const score = questions.reduce((s,q) => {
      const correct = safeParseArray(q.correct_answers);
      const ans = answers[q.id];
      return ans && correct.map(c=>c.toLowerCase().trim()).includes(ans.toLowerCase().trim()) ? s+1 : s;
    }, 0);
    onFinish({ questions, answers, score, total: questions.length, auto });
  }, [questions, answers, freeTrial, showPaywall]);

  if (loading) return (
    <div style={{ minHeight:'100dvh', display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:16, background: isMobile ? '#0F172A' : '#F0F4F8' }}>
      <div style={{ width:40, height:40, border:'4px solid #E2E8F0', borderTop:'4px solid #2563EB', borderRadius:'50%', animation:'spin 0.7s linear infinite' }}/>
      <p style={{ color: isMobile ? 'rgba(255,255,255,0.7)' : '#64748B', fontFamily:"'Inter',sans-serif" }}>Loading {config.count} questions...</p>
    </div>
  );

  // Quota was already exhausted before this session could even start (see
  // loadQuestions' catch block above) — nothing to practice on, so show
  // just the paywall rather than the question engine against an empty list.
  if (questions.length === 0 && showPaywall) {
    return (
      <div style={{ minHeight:'100dvh', background: isMobile ? '#0F172A' : '#F0F4F8' }}>
        <FreeTrialPaywall onDismiss={() => window.history.back()} />
      </div>
    );
  }

  const q = questions[current];
  if (!q) return null;
  const opts = safeParseArray(q.options);
  const correctAnswers = safeParseArray(q.correct_answers).map(c=>c.toLowerCase().trim());
  const selected = answers[q.id];
  const isRevealed = revealed[q.id];
  const answered = Object.keys(answers).length;
  const isWarning = timeLeft < 300 && config.mode !== 'study';
  const isCritical = timeLeft < 60 && config.mode !== 'study';

  const paletteStatus = (i) => {
    const qq = questions[i];
    if (i === current) return 'current';
    if (bookmarked.has(qq?.id)) return 'bookmarked';
    if (answers[qq?.id]) return 'answered';
    return 'unanswered';
  };
  const palColors = { current:{bg:'#2563EB',color:'#fff',border:'#2563EB'}, answered:{bg:'#DCFCE7',color:'#16A34A',border:'#16A34A'}, bookmarked:{bg:'#FEF3C7',color:'#D97706',border:'#D97706'}, unanswered:{bg:'#fff',color:'#64748B',border:'#CBD5E1'} };

  if (isMobile) {
    return (
      <>
        <MobileExamScreen
          config={config} questions={questions} answers={answers} revealed={revealed}
          bookmarked={bookmarked} current={current} setCurrent={setCurrent}
          timeLeft={timeLeft} showCalc={showCalc} setShowCalc={setShowCalc}
          attempts={attempts} isOnline={isOnline} usingOfflineCache={usingOfflineCache}
          lowData={lowData} toggleLowData={toggleLowData} adaptiveDifficulty={adaptiveDifficulty}
          selectAnswer={selectAnswer} handleSubmit={handleSubmit} setBookmarked={setBookmarked}
          setRevealed={setRevealed} onFinish={onFinish} submittedRef={submittedRef}
          paletteStatus={paletteStatus}
        />
        {showPaywall && <FreeTrialPaywall onDismiss={() => setShowPaywall(false)} />}
      </>
    );
  }

  return (
    <div style={{ minHeight:'100dvh', background:'#F0F4F8', fontFamily:"'Inter',sans-serif", display:'flex', flexDirection:'column' }}>

      {/* ── TOOLBAR ── */}
      <div style={{ background:'#1E3A5F', padding:'0 16px', display:'flex', alignItems:'center', gap:0, flexShrink:0, overflowX:'auto' }}>
        {[
          { icon:'⟵', label:'Log Out', action:() => onFinish({questions,answers,score:0,total:questions.length,cancelled:true}) },
          { icon:'🧮', label:'Calculator', action:() => setShowCalc(c=>!c) },
          { icon:'🔖', label:'Bookmark', action:() => setBookmarked(b=>{ const n=new Set(b); n.has(q.id)?n.delete(q.id):n.add(q.id); return n; }) },
          { icon:'💡', label:'Explanation', action:() => setRevealed(r=>({...r,[q.id]:true})) },
          { icon: lowData ? '🐢' : '📶', label: lowData ? 'Low Data' : 'Full Data', action: toggleLowData },
        ].map(btn => (
          <button key={btn.label} onClick={btn.action} style={{
            display:'flex', flexDirection:'column', alignItems:'center', gap:3,
            padding:'8px 16px', background: btn.label==='Low Data' ? 'rgba(255,255,255,0.12)' : 'transparent', border:'none',
            borderRight:'1px solid rgba(255,255,255,0.1)',
            color:'rgba(255,255,255,0.85)', cursor:'pointer', fontFamily:"'Inter',sans-serif",
            transition:'background 0.1s', whiteSpace:'nowrap', minWidth:70,
          }}
            onMouseOver={e=>e.currentTarget.style.background='rgba(255,255,255,0.1)'}
            onMouseOut={e=>e.currentTarget.style.background = btn.label==='Low Data' ? 'rgba(255,255,255,0.12)' : 'transparent'}
          >
            <span style={{ fontSize:16 }}>{btn.icon}</span>
            <span style={{ fontSize:10, fontWeight:600 }}>{btn.label}</span>
          </button>
        ))}
        <div style={{ flex:1 }}/>
        {config.mode === 'adaptive' && (
          <div style={{ padding:'4px 12px', display:'flex', alignItems:'center', gap:6, borderLeft:'1px solid rgba(255,255,255,0.1)', fontSize:11.5, fontWeight:700, whiteSpace:'nowrap', color: adaptiveDifficulty==='hard' ? '#FCA5A5' : adaptiveDifficulty==='easy' ? '#86EFAC' : '#93C5FD' }}>
            🎯 {adaptiveDifficulty.charAt(0).toUpperCase()+adaptiveDifficulty.slice(1)}
          </div>
        )}
        {(!isOnline || usingOfflineCache) && (
          <div style={{ padding:'4px 12px', display:'flex', alignItems:'center', gap:6, borderLeft:'1px solid rgba(255,255,255,0.1)', fontSize:11.5, color:'#FCD34D', fontWeight:600, whiteSpace:'nowrap' }}>
            📡 {!isOnline ? 'Offline' : 'Saved set'}
          </div>
        )}
        {/* Timer */}
        <div style={{ padding:'4px 16px', display:'flex', alignItems:'center', gap:8, borderLeft:'1px solid rgba(255,255,255,0.1)' }}>
          <span style={{ fontSize:13 }}>⏱</span>
          <span style={{ fontFamily:'monospace', fontSize:15, fontWeight:700, color: isCritical?'#FCA5A5':isWarning?'#FCD34D':'#fff' }}>
            {config.mode==='study' ? '∞' : formatTime(timeLeft)}
          </span>
        </div>
        <div style={{ padding:'4px 16px', borderLeft:'1px solid rgba(255,255,255,0.1)', color:'rgba(255,255,255,0.7)', fontSize:12 }}>
          Attempt: {attempts}/{config.count}
        </div>
      </div>

      {/* ── SUBJECT TAB ── */}
      <div style={{ background:'#fff', borderBottom:'2px solid #E2E8F0', padding:'0 16px', display:'flex', alignItems:'center', gap:0, flexShrink:0 }}>
        <div style={{ padding:'10px 20px', borderBottom:'3px solid #2563EB', color:'#2563EB', fontWeight:700, fontSize:13, marginBottom:-2 }}>{config.subject}</div>
        <div style={{ marginLeft:'auto', padding:'6px 16px', fontSize:12, color:'#64748B' }}>
          {config.examType} {config.year !== 'All Years' ? `· ${config.year}` : ''} · {config.mode.toUpperCase()}
        </div>
      </div>

      {/* ── MAIN CONTENT ── */}
      <div style={{ flex:1, display:'flex', overflow:'hidden' }}>

        {/* LEFT: Palette */}
        <div style={{ width:200, background:'#fff', borderRight:'1px solid #E2E8F0', overflowY:'auto', flexShrink:0, padding:'12px 10px' }}>
          <div style={{ fontSize:11, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:10, paddingLeft:4 }}>
            Questions
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:4 }}>
            {questions.map((_,i) => {
              const st = paletteStatus(i);
              const pc = palColors[st];
              return (
                <button key={i} onClick={() => setCurrent(i)} style={{
                  width:32, height:32, borderRadius:6, border:`1.5px solid ${pc.border}`,
                  background:pc.bg, color:pc.color, fontWeight:700, fontSize:11,
                  cursor:'pointer', transition:'all 0.1s', fontFamily:"'Inter',sans-serif",
                }}>{i+1}</button>
              );
            })}
          </div>
          {/* Legend */}
          <div style={{ marginTop:14, display:'flex', flexDirection:'column', gap:5 }}>
            {[['#16A34A','Answered'],['#2563EB','Current'],['#D97706','Bookmarked'],['#CBD5E1','Not Done']].map(([c,l])=>(
              <div key={l} style={{ display:'flex', alignItems:'center', gap:6, fontSize:10, color:'#64748B' }}>
                <div style={{ width:10, height:10, borderRadius:2, background:c }}/>
                {l}
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT: Question */}
        <div style={{ flex:1, overflowY:'auto', padding:'20px 24px' }}>
          <div style={{ maxWidth:720, margin:'0 auto' }}>

            {/* Question header */}
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:14 }}>
              <span style={{ fontSize:12, fontWeight:700, color:'#2563EB', background:'#EFF6FF', padding:'3px 12px', borderRadius:20, border:'1px solid #BFDBFE' }}>Question {current+1} of {questions.length}</span>
              {bookmarked.has(q.id) && <span style={{ fontSize:11, fontWeight:700, color:'#D97706', background:'#FEF3C7', padding:'3px 10px', borderRadius:20 }}>🔖 Bookmarked</span>}
              {q.marks && <span style={{ fontSize:11, color:'#64748B' }}>{q.marks} mark{parseFloat(q.marks)>1?'s':''}</span>}
            </div>

            {/* Question text */}
            <div style={{ background:'#fff', border:'1px solid #E2E8F0', borderRadius:12, padding:'20px 22px', marginBottom:18, fontSize:15, lineHeight:1.85, color:'#1E293B', fontWeight:500, boxShadow:'0 1px 4px rgba(0,0,0,0.05)' }}>
              <MathText text={q.question_text} />
              {q.media_url && !lowData && (
                <img src={q.media_url} alt="Question diagram" style={{ display:'block', maxWidth:'100%', maxHeight:340, marginTop:14, borderRadius:10, border:'1px solid #E2E8F0' }} />
              )}
              {q.media_url && lowData && (
                <div style={{ marginTop:14, padding:'10px 14px', background:'#F1F5F9', borderRadius:10, border:'1px dashed #CBD5E1', fontSize:12.5, color:'#64748B' }}>
                  🖼️ Diagram hidden — Low Data mode is on
                </div>
              )}
            </div>

            {/* Options — radio style */}
            <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:20 }}>
              {opts.map((opt, i) => {
                const isSelected = selected === opt;
                const isCorrect = correctAnswers.includes(opt.toLowerCase().trim());
                let bg='#fff', border='#CBD5E1', textColor='#374151', radioColor='#CBD5E1';
                if (isRevealed) {
                  if (isCorrect)        { bg='#F0FDF4'; border='#16A34A'; textColor='#15803D'; radioColor='#16A34A'; }
                  else if (isSelected)  { bg='#FEF2F2'; border='#EF4444'; textColor='#DC2626'; radioColor='#EF4444'; }
                } else if (isSelected)  { bg='#EFF6FF'; border='#2563EB'; textColor='#1D4ED8'; radioColor='#2563EB'; }

                return (
                  <button key={i} onClick={() => !submittedRef.current && selectAnswer(q.id, opt)} style={{
                    display:'flex', alignItems:'flex-start', gap:14, padding:'13px 16px',
                    background:bg, border:`1.5px solid ${border}`, borderRadius:10,
                    cursor:submittedRef.current?'default':'pointer', textAlign:'left', width:'100%',
                    transition:'all 0.12s', fontFamily:"'Inter',sans-serif",
                    boxShadow: isSelected && !isRevealed ? '0 2px 8px rgba(37,99,235,0.15)' : '0 1px 3px rgba(0,0,0,0.04)',
                  }}>
                    {/* Radio */}
                    <div style={{ width:20, height:20, borderRadius:'50%', border:`2px solid ${radioColor}`, background: isSelected||isRevealed&&isCorrect ? radioColor : '#fff', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, marginTop:1, transition:'all 0.12s' }}>
                      {(isSelected || (isRevealed && isCorrect)) && <div style={{ width:8, height:8, borderRadius:'50%', background:'#fff' }}/>}
                    </div>
                    {/* Letter */}
                    <span style={{ fontSize:13, fontWeight:800, color:radioColor, flexShrink:0, minWidth:16, marginTop:1 }}>{LETTERS[i]}</span>
                    {/* Text */}
                    <span style={{ fontSize:14, fontWeight: isSelected?600:400, color:textColor, lineHeight:1.6 }}><MathText text={opt} inline /></span>
                    {isRevealed && isCorrect && <span style={{ marginLeft:'auto', fontSize:16, flexShrink:0 }}>✓</span>}
                    {isRevealed && isSelected && !isCorrect && <span style={{ marginLeft:'auto', fontSize:16, flexShrink:0 }}>✗</span>}
                  </button>
                );
              })}
            </div>

            {/* Explanation */}
            {isRevealed && (
              <div style={{ marginBottom:16 }}>
                <ExplanationBox question={q} theme="light" />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── BOTTOM NAV ── */}
      <div style={{ background:'#fff', borderTop:'1px solid #E2E8F0', padding:'12px 24px', display:'flex', alignItems:'center', justifyContent:'center', gap:12, flexShrink:0 }}>
        <button onClick={() => setCurrent(c=>Math.max(0,c-1))} disabled={current===0}
          style={{ padding:'9px 24px', borderRadius:20, border:'1.5px solid #CBD5E1', background:'#fff', color:current===0?'#CBD5E1':'#374151', fontWeight:700, fontSize:13, cursor:current===0?'default':'pointer', fontFamily:"'Inter',sans-serif", transition:'all 0.12s' }}>
          ← Previous
        </button>

        <button onClick={() => !submittedRef.current && handleSubmit(false)}
          style={{ padding:'9px 28px', borderRadius:20, border:'2px solid #DC2626', background:'#FEF2F2', color:'#DC2626', fontWeight:700, fontSize:13, cursor:'pointer', fontFamily:"'Inter',sans-serif", transition:'all 0.12s' }}
          onMouseOver={e=>{e.currentTarget.style.background='#DC2626';e.currentTarget.style.color='#fff';}}
          onMouseOut={e=>{e.currentTarget.style.background='#FEF2F2';e.currentTarget.style.color='#DC2626';}}>
          Submit
        </button>

        <button onClick={() => setCurrent(c=>Math.min(questions.length-1,c+1))} disabled={current===questions.length-1}
          style={{ padding:'9px 24px', borderRadius:20, border:'1.5px solid #2563EB', background:'#EFF6FF', color:current===questions.length-1?'#CBD5E1':'#2563EB', fontWeight:700, fontSize:13, cursor:current===questions.length-1?'default':'pointer', fontFamily:"'Inter',sans-serif", transition:'all 0.12s' }}>
          Next →
        </button>
      </div>

      {showCalc && <SimpleCalc onClose={() => setShowCalc(false)} />}
      {showPaywall && <FreeTrialPaywall onDismiss={() => setShowPaywall(false)} />}
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

// ── MOBILE EXAM SCREEN ───────────────────────────────────────
// Purpose-built for phones: full-width question focus, no fixed sidebar,
// question navigator lives in a bottom sheet instead of eating screen width.
function MobileExamScreen({
  config, questions, answers, revealed, bookmarked, current, setCurrent,
  timeLeft, showCalc, setShowCalc, attempts, isOnline, usingOfflineCache,
  lowData, toggleLowData, adaptiveDifficulty, selectAnswer, handleSubmit,
  setBookmarked, setRevealed, onFinish, submittedRef, paletteStatus,
}) {
  const [showNav, setShowNav] = useState(false);
  const [showTools, setShowTools] = useState(false);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);

  const q = questions[current];
  if (!q) return null;
  const opts = safeParseArray(q.options);
  const correctAnswers = safeParseArray(q.correct_answers).map(c => c.toLowerCase().trim());
  const selected = answers[q.id];
  const isRevealed = revealed[q.id];
  const isBookmarked = bookmarked.has(q.id);
  const answeredCount = Object.keys(answers).length;
  const remainingCount = questions.length - answeredCount;
  const bookmarkedCount = bookmarked.size;
  const isLast = current === questions.length - 1;
  const isWarning = timeLeft < 300 && config.mode !== 'study';
  const isCritical = timeLeft < 60 && config.mode !== 'study';
  const progressPct = Math.round(((current + 1) / questions.length) * 100);

  const palColors = { current:{bg:'#2563EB',color:'#fff',border:'#2563EB'}, answered:{bg:'#DCFCE7',color:'#16A34A',border:'#16A34A'}, bookmarked:{bg:'#FEF3C7',color:'#D97706',border:'#D97706'}, unanswered:{bg:'#fff',color:'#64748B',border:'#E2E8F0'} };

  const goTo = (i) => { setCurrent(i); setShowNav(false); };
  const toggleBookmark = () => setBookmarked(b => { const n = new Set(b); n.has(q.id) ? n.delete(q.id) : n.add(q.id); return n; });

  const encouragement =
    progressPct >= 100 ? "Last one — you've got this!" :
    progressPct >= 75  ? "Almost there. Keep going." :
    progressPct >= 50  ? "Halfway done. Great pace." :
    progressPct >= 25  ? "Good start. Stay focused." : null;

  return (
    <div style={{ minHeight:'100dvh', background:'#0F172A', fontFamily:"'Inter',sans-serif", display:'flex', flexDirection:'column' }}>

      {/* ── STICKY HEADER ── */}
      <div style={{ position:'sticky', top:0, zIndex:30, background:'#1E293B', padding:'10px 14px 8px', flexShrink:0, boxShadow:'0 2px 8px rgba(0,0,0,0.2)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <button onClick={() => onFinish({ questions, answers, score:0, total:questions.length, cancelled:true })}
            style={{ background:'none', border:'none', color:'rgba(255,255,255,0.8)', fontSize:18, padding:4, cursor:'pointer', flexShrink:0 }}>←</button>
          <div style={{ flex:1, minWidth:0, textAlign:'center' }}>
            <div style={{ color:'#fff', fontWeight:800, fontSize:14, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{config.subject}</div>
            <div style={{ color:'rgba(255,255,255,0.55)', fontSize:10.5 }}>{config.examType} · {config.mode.toUpperCase()}</div>
          </div>
          <button onClick={() => setShowNav(true)} style={{
            display:'flex', alignItems:'center', gap:4, background:'rgba(255,255,255,0.1)', border:'none',
            borderRadius:20, padding:'6px 12px', color:'#fff', fontWeight:700, fontSize:12.5, cursor:'pointer', flexShrink:0,
          }}>
            {current+1}/{questions.length} <span style={{ fontSize:9 }}>▾</span>
          </button>
        </div>

        {/* Progress bar */}
        <div style={{ height:4, background:'rgba(255,255,255,0.12)', borderRadius:2, marginTop:10, overflow:'hidden' }}>
          <div style={{ height:'100%', width:`${progressPct}%`, background:'linear-gradient(90deg,#3B82F6,#60A5FA)', borderRadius:2, transition:'width 0.25s ease' }}/>
        </div>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:5 }}>
          <span style={{ color:'rgba(255,255,255,0.5)', fontSize:10.5 }}>Question {current+1} of {questions.length} · {progressPct}%</span>
          <span style={{ fontFamily:'monospace', fontSize:12.5, fontWeight:700, color: isCritical?'#FCA5A5':isWarning?'#FCD34D':'rgba(255,255,255,0.85)' }}>
            ⏱ {config.mode==='study' ? '∞' : formatTime(timeLeft)}
          </span>
        </div>
      </div>

      {/* ── STUDY TOOLS STRIP ── */}
      <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 14px', background:'#1E293B', borderTop:'1px solid rgba(255,255,255,0.06)', flexShrink:0, overflowX:'auto' }}>
        <button onClick={() => setShowCalc(c=>!c)} style={toolChipStyle}>🧮 Calculator</button>
        <button onClick={toggleBookmark} style={{ ...toolChipStyle, background: isBookmarked ? 'rgba(217,119,6,0.25)' : toolChipStyle.background, color: isBookmarked ? '#FCD34D' : toolChipStyle.color }}>
          {isBookmarked ? '🔖 Saved' : '🔖 Bookmark'}
        </button>
        <button onClick={() => setRevealed(r=>({...r,[q.id]:true}))} style={toolChipStyle}>💡 Explanation</button>
        <button onClick={() => setShowTools(true)} style={toolChipStyle}>⋮ More</button>
        <div style={{ flex:1 }}/>
      </div>

      {/* ── QUESTION CONTENT (scrollable) ── */}
      <div style={{ flex:1, overflowY:'auto', padding:'16px 16px 100px' }}>
        {encouragement && (
          <div style={{ textAlign:'center', color:'rgba(255,255,255,0.4)', fontSize:11.5, marginBottom:12, fontStyle:'italic' }}>{encouragement}</div>
        )}

        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12, flexWrap:'wrap' }}>
          <span style={{ fontSize:11.5, fontWeight:700, color:'#93C5FD', background:'rgba(59,130,246,0.15)', padding:'3px 11px', borderRadius:20 }}>Question {current+1}</span>
          {isBookmarked && <span style={{ fontSize:11, fontWeight:700, color:'#FCD34D', background:'rgba(217,119,6,0.18)', padding:'3px 10px', borderRadius:20 }}>🔖 Bookmarked</span>}
          {config.mode === 'adaptive' && (
            <span style={{ fontSize:11, fontWeight:700, padding:'3px 10px', borderRadius:20, background:'rgba(255,255,255,0.08)', color: adaptiveDifficulty==='hard'?'#FCA5A5':adaptiveDifficulty==='easy'?'#86EFAC':'#93C5FD' }}>
              🎯 {adaptiveDifficulty}
            </span>
          )}
          {(!isOnline || usingOfflineCache) && (
            <span style={{ fontSize:11, fontWeight:700, color:'#FCD34D', background:'rgba(217,119,6,0.15)', padding:'3px 10px', borderRadius:20 }}>📡 {!isOnline?'Offline':'Saved set'}</span>
          )}
        </div>

        {/* Question card */}
        <div style={{ background:'#1E293B', border:'1px solid rgba(255,255,255,0.08)', borderRadius:16, padding:'18px 18px', marginBottom:16, fontSize:17, lineHeight:1.65, color:'#F1F5F9', fontWeight:500 }}>
          <MathText text={q.question_text} />
          {q.media_url && !lowData && (
            <img src={q.media_url} alt="Question diagram" style={{ display:'block', maxWidth:'100%', maxHeight:280, marginTop:14, borderRadius:10, border:'1px solid rgba(255,255,255,0.1)' }} />
          )}
          {q.media_url && lowData && (
            <div style={{ marginTop:14, padding:'10px 14px', background:'rgba(255,255,255,0.05)', borderRadius:10, border:'1px dashed rgba(255,255,255,0.15)', fontSize:12.5, color:'rgba(255,255,255,0.5)' }}>
              🖼️ Diagram hidden — Low Data mode is on
            </div>
          )}
        </div>

        {/* Options — full-width touch cards */}
        <div style={{ display:'flex', flexDirection:'column', gap:11, marginBottom:18 }}>
          {opts.map((opt, i) => {
            const isSelected = selected === opt;
            const isCorrect = correctAnswers.includes(opt.toLowerCase().trim());
            let bg='rgba(255,255,255,0.04)', border='rgba(255,255,255,0.12)', textColor='#E2E8F0', badgeColor='rgba(255,255,255,0.5)';
            if (isRevealed) {
              if (isCorrect)        { bg='rgba(22,163,74,0.15)'; border='#16A34A'; textColor='#86EFAC'; badgeColor='#16A34A'; }
              else if (isSelected)  { bg='rgba(220,38,38,0.15)'; border='#EF4444'; textColor='#FCA5A5'; badgeColor='#EF4444'; }
            } else if (isSelected)  { bg='rgba(37,99,235,0.18)'; border='#3B82F6'; textColor='#BFDBFE'; badgeColor='#3B82F6'; }

            return (
              <button
                key={i}
                onClick={() => !submittedRef.current && selectAnswer(q.id, opt)}
                style={{
                  display:'flex', alignItems:'center', gap:14, padding:'16px 16px', minHeight:56,
                  background:bg, border:`1.5px solid ${border}`, borderRadius:14,
                  cursor: submittedRef.current ? 'default' : 'pointer', textAlign:'left', width:'100%',
                  transition:'background 0.12s, border-color 0.12s', fontFamily:"'Inter',sans-serif",
                  WebkitTapHighlightColor:'transparent',
                }}
              >
                <span style={{
                  width:30, height:30, borderRadius:9, border:`1.5px solid ${badgeColor}`, background: isSelected||(isRevealed&&isCorrect) ? badgeColor : 'transparent',
                  display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
                  fontSize:13, fontWeight:800, color: isSelected||(isRevealed&&isCorrect) ? '#fff' : badgeColor,
                }}>{LETTERS[i]}</span>
                <span style={{ fontSize:15, fontWeight: isSelected?600:400, color:textColor, lineHeight:1.5, flex:1 }}><MathText text={opt} inline /></span>
                {isRevealed && isCorrect && <span style={{ fontSize:18, flexShrink:0 }}>✓</span>}
                {isRevealed && isSelected && !isCorrect && <span style={{ fontSize:18, flexShrink:0 }}>✗</span>}
              </button>
            );
          })}
        </div>

        {/* Explanation */}
        {isRevealed && (
          <div style={{ marginBottom:16 }}>
            <ExplanationBox question={q} theme="dark" />
          </div>
        )}
      </div>

      {/* ── STICKY BOTTOM ACTION BAR ── */}
      <div style={{ position:'sticky', bottom:0, background:'#1E293B', borderTop:'1px solid rgba(255,255,255,0.08)', padding:'10px 14px', display:'flex', alignItems:'center', gap:8, flexShrink:0, paddingBottom:'calc(10px + env(safe-area-inset-bottom))' }}>
        <button onClick={toggleBookmark} style={{
          width:44, height:44, borderRadius:12, flexShrink:0, border:'1.5px solid rgba(255,255,255,0.15)',
          background: isBookmarked ? 'rgba(217,119,6,0.2)' : 'rgba(255,255,255,0.05)', fontSize:18, cursor:'pointer',
        }}>🔖</button>
        <button onClick={() => setCurrent(c=>Math.max(0,c-1))} disabled={current===0} style={{
          flex:1, padding:'13px 0', borderRadius:12, border:'1.5px solid rgba(255,255,255,0.15)',
          background:'transparent', color: current===0?'rgba(255,255,255,0.25)':'rgba(255,255,255,0.85)',
          fontWeight:700, fontSize:14, cursor: current===0?'default':'pointer', fontFamily:"'Inter',sans-serif",
        }}>← Prev</button>
        {isLast ? (
          <button onClick={() => setShowSubmitConfirm(true)} style={{
            flex:1.4, padding:'13px 0', borderRadius:12, border:'none', background:'#DC2626',
            color:'#fff', fontWeight:800, fontSize:14, cursor:'pointer', fontFamily:"'Inter',sans-serif",
          }}>Submit Exam</button>
        ) : (
          <button onClick={() => setCurrent(c=>Math.min(questions.length-1,c+1))} style={{
            flex:1.4, padding:'13px 0', borderRadius:12, border:'none', background:'#2563EB',
            color:'#fff', fontWeight:800, fontSize:14, cursor:'pointer', fontFamily:"'Inter',sans-serif",
          }}>Next →</button>
        )}
      </div>

      {/* ── QUESTION NAVIGATOR BOTTOM SHEET ── */}
      {showNav && (
        <div style={{ position:'fixed', inset:0, zIndex:50, display:'flex', alignItems:'flex-end' }}>
          <div onClick={() => setShowNav(false)} style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.55)' }}/>
          <div style={{ position:'relative', width:'100%', maxHeight:'75vh', background:'#1E293B', borderRadius:'20px 20px 0 0', padding:'14px 18px calc(18px + env(safe-area-inset-bottom))', display:'flex', flexDirection:'column' }}>
            <div style={{ width:36, height:4, background:'rgba(255,255,255,0.2)', borderRadius:2, margin:'0 auto 14px' }}/>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
              <span style={{ color:'#fff', fontWeight:800, fontSize:15 }}>Questions</span>
              <button onClick={() => setShowNav(false)} style={{ background:'none', border:'none', color:'rgba(255,255,255,0.6)', fontSize:20, cursor:'pointer' }}>✕</button>
            </div>

            <div style={{ overflowY:'auto', flex:1 }}>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:8, marginBottom:16 }}>
                {questions.map((_,i) => {
                  const st = paletteStatus(i);
                  const pc = palColors[st];
                  return (
                    <button key={i} onClick={() => goTo(i)} style={{
                      aspectRatio:'1', borderRadius:10, border:`1.5px solid ${pc.border}`,
                      background:pc.bg, color:pc.color, fontWeight:700, fontSize:13,
                      cursor:'pointer', fontFamily:"'Inter',sans-serif",
                    }}>{i+1}</button>
                  );
                })}
              </div>

              <div style={{ display:'flex', flexWrap:'wrap', gap:12, marginBottom:14 }}>
                {[['#16A34A','Answered'],['#2563EB','Current'],['#D97706','Bookmarked'],['#94A3B8','Not Done']].map(([c,l])=>(
                  <div key={l} style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, color:'rgba(255,255,255,0.6)' }}>
                    <div style={{ width:10, height:10, borderRadius:3, background:c }}/>{l}
                  </div>
                ))}
              </div>

              <div style={{ textAlign:'center', fontSize:12.5, color:'rgba(255,255,255,0.6)', marginBottom:14 }}>
                Answered: <strong style={{ color:'#86EFAC' }}>{answeredCount}</strong> · Remaining: <strong style={{ color:'#FCA5A5' }}>{remainingCount}</strong> · Bookmarked: <strong style={{ color:'#FCD34D' }}>{bookmarkedCount}</strong>
              </div>

              <button onClick={() => { setShowNav(false); setShowSubmitConfirm(true); }} style={{
                width:'100%', padding:'12px 0', borderRadius:12, border:'1.5px solid #DC2626', background:'transparent',
                color:'#FCA5A5', fontWeight:700, fontSize:13.5, cursor:'pointer', fontFamily:"'Inter',sans-serif",
              }}>Submit Exam Now</button>
            </div>
          </div>
        </div>
      )}

      {/* ── STUDY TOOLS BOTTOM SHEET (secondary/less-used) ── */}
      {showTools && (
        <div style={{ position:'fixed', inset:0, zIndex:50, display:'flex', alignItems:'flex-end' }}>
          <div onClick={() => setShowTools(false)} style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.55)' }}/>
          <div style={{ position:'relative', width:'100%', background:'#1E293B', borderRadius:'20px 20px 0 0', padding:'14px 18px calc(18px + env(safe-area-inset-bottom))' }}>
            <div style={{ width:36, height:4, background:'rgba(255,255,255,0.2)', borderRadius:2, margin:'0 auto 14px' }}/>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
              <span style={{ color:'#fff', fontWeight:800, fontSize:15 }}>More Tools</span>
              <button onClick={() => setShowTools(false)} style={{ background:'none', border:'none', color:'rgba(255,255,255,0.6)', fontSize:20, cursor:'pointer' }}>✕</button>
            </div>
            <button onClick={toggleLowData} style={{
              width:'100%', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'14px 16px',
              borderRadius:12, border:'1px solid rgba(255,255,255,0.1)', background:'rgba(255,255,255,0.04)',
              color:'#E2E8F0', fontWeight:600, fontSize:14, cursor:'pointer', marginBottom:10, fontFamily:"'Inter',sans-serif",
            }}>
              <span>{lowData ? '🐢 Low Data Mode' : '📶 Full Data Mode'}</span>
              <span style={{ fontSize:12, color:'rgba(255,255,255,0.5)' }}>{lowData ? 'Diagrams hidden' : 'Tap to save data'}</span>
            </button>
            <div style={{ fontSize:12, color:'rgba(255,255,255,0.45)', textAlign:'center', marginTop:4 }}>
              Attempt {attempts}/{config.count} · {config.year !== 'All Years' ? `${config.year} · ` : ''}{config.mode.toUpperCase()}
            </div>
          </div>
        </div>
      )}

      {/* ── SUBMIT CONFIRMATION ── */}
      {showSubmitConfirm && (
        <div style={{ position:'fixed', inset:0, zIndex:60, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}>
          <div onClick={() => setShowSubmitConfirm(false)} style={{ position:'absolute', inset:0, background:'rgba(0,0,0,0.65)' }}/>
          <div style={{ position:'relative', width:'100%', maxWidth:340, background:'#1E293B', borderRadius:18, padding:24, textAlign:'center' }}>
            <div style={{ fontSize:17, fontWeight:800, color:'#fff', marginBottom:10 }}>Submit your exam?</div>
            <div style={{ fontSize:13.5, color:'rgba(255,255,255,0.7)', lineHeight:1.6, marginBottom:18 }}>
              You have answered <strong style={{ color:'#86EFAC' }}>{answeredCount}</strong> of {questions.length} questions.
              {remainingCount > 0 && <><br /><strong style={{ color:'#FCA5A5' }}>{remainingCount}</strong> question{remainingCount!==1?'s are':' is'} still unanswered.</>}
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              <button onClick={() => setShowSubmitConfirm(false)} style={{
                padding:'12px 0', borderRadius:12, border:'1.5px solid rgba(255,255,255,0.15)', background:'transparent',
                color:'#E2E8F0', fontWeight:700, fontSize:14, cursor:'pointer', fontFamily:"'Inter',sans-serif",
              }}>Continue Reviewing</button>
              <button onClick={() => { setShowSubmitConfirm(false); handleSubmit(false); }} style={{
                padding:'12px 0', borderRadius:12, border:'none', background:'#DC2626',
                color:'#fff', fontWeight:800, fontSize:14, cursor:'pointer', fontFamily:"'Inter',sans-serif",
              }}>Submit Exam</button>
            </div>
          </div>
        </div>
      )}

      {showCalc && <SimpleCalc onClose={() => setShowCalc(false)} />}
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

const toolChipStyle = {
  display:'flex', alignItems:'center', gap:5, padding:'7px 13px', borderRadius:20,
  border:'1px solid rgba(255,255,255,0.1)', background:'rgba(255,255,255,0.05)',
  color:'rgba(255,255,255,0.8)', fontSize:12, fontWeight:600, cursor:'pointer',
  whiteSpace:'nowrap', flexShrink:0, fontFamily:"'Inter',sans-serif",
};

// ── RESULTS ───────────────────────────────────────────────────
function ResultsScreen({ result, config, onRetry, onNew }) {
  const { score, total, questions, answers, cancelled } = result;
  const pct = total > 0 ? (score/total)*100 : 0;
  const passed = pct >= 50;
  const [tab, setTab] = useState('summary');

  const getGrade = p => {
    if (p>=90) return {g:'A1',label:'Excellent',c:'#16A34A'};
    if (p>=80) return {g:'B2',label:'Very Good',c:'#22C55E'};
    if (p>=75) return {g:'B3',label:'Good',c:'#2563EB'};
    if (p>=60) return {g:'C4',label:'Credit',c:'#7C3AED'};
    if (p>=50) return {g:'E8',label:'Pass',c:'#D97706'};
    return {g:'F9',label:'Fail',c:'#DC2626'};
  };
  const {g,label,c} = getGrade(pct);

  return (
    <div style={{ minHeight:'100dvh', background:'#F0F4F8', fontFamily:"'Inter',sans-serif" }}>
      <div style={{ background:'#1E3A5F', padding:'12px 24px', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div style={{ color:'#fff', fontWeight:800, fontSize:16 }}>Session Results</div>
        <div style={{ display:'flex', gap:10 }}>
          <button onClick={onRetry} style={{ padding:'7px 18px', background:'rgba(255,255,255,0.15)', border:'1px solid rgba(255,255,255,0.3)', color:'#fff', borderRadius:20, cursor:'pointer', fontWeight:600, fontSize:13, fontFamily:"'Inter',sans-serif" }}>↩ Retry</button>
          <button onClick={onNew} style={{ padding:'7px 18px', background:'#2563EB', border:'none', color:'#fff', borderRadius:20, cursor:'pointer', fontWeight:700, fontSize:13, fontFamily:"'Inter',sans-serif" }}>New Session</button>
        </div>
      </div>

      <div style={{ maxWidth:760, margin:'0 auto', padding:'28px 16px 60px' }}>

        {/* Score hero */}
        <div style={{ background:`linear-gradient(135deg,${passed?'#16A34A':'#DC2626'},${passed?'#22C55E':'#EF4444'})`, borderRadius:16, padding:'28px', marginBottom:20, color:'#fff', textAlign:'center', boxShadow:`0 8px 32px ${passed?'rgba(22,163,74,0.3)':'rgba(220,38,38,0.3)'}` }}>
          <div style={{ fontSize:48, marginBottom:8 }}>{passed?'🎉':'📖'}</div>
          <div style={{ fontSize:56, fontWeight:900, letterSpacing:'-0.04em', lineHeight:1 }}>{pct.toFixed(1)}<span style={{ fontSize:24, opacity:0.7 }}>%</span></div>
          <div style={{ fontSize:20, fontWeight:700, marginTop:4 }}>Grade {g} — {label}</div>
          <div style={{ display:'flex', gap:24, justifyContent:'center', marginTop:16 }}>
            {[['✓ Correct',score,'rgba(255,255,255,0.2)'],['✗ Wrong',total-score,'rgba(255,255,255,0.2)'],['— Skipped',total-Object.keys(answers).length,'rgba(255,255,255,0.2)']].map(([k,v,bg])=>(
              <div key={k} style={{ textAlign:'center', padding:'8px 16px', background:bg, borderRadius:10 }}>
                <div style={{ fontSize:20, fontWeight:800 }}>{v}</div>
                <div style={{ fontSize:11, opacity:0.8 }}>{k}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', background:'#fff', borderRadius:10, padding:4, marginBottom:16, gap:4, boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
          {[['summary','📊 Summary'],['review','📝 Review Answers']].map(([id,label])=>(
            <button key={id} onClick={()=>setTab(id)} style={{ flex:1, padding:'9px', border:'none', borderRadius:8, cursor:'pointer', background:tab===id?'#2563EB':'transparent', color:tab===id?'#fff':'#64748B', fontFamily:"'Inter',sans-serif", fontWeight:700, fontSize:13, transition:'all 0.15s' }}>{label}</button>
          ))}
        </div>

        {tab==='summary' && (
          <div style={{ background:'#fff', borderRadius:12, padding:'20px', boxShadow:'0 1px 4px rgba(0,0,0,0.08)' }}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              {[['Score',`${score}/${total}`,c],['Percentage',`${pct.toFixed(2)}%`,c],['Grade',g,c],['Result',passed?'PASSED':'FAILED',passed?'#16A34A':'#DC2626'],['Subject',config.subject,'#1E293B'],['Exam',config.examType,'#1E293B'],['Mode',config.mode,'#1E293B'],['Year',config.year,'#1E293B']].map(([k,v,col])=>(
                <div key={k} style={{ padding:'12px', background:'#F8FAFC', borderRadius:9, border:'1px solid #E2E8F0' }}>
                  <div style={{ fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:'0.07em', marginBottom:4 }}>{k}</div>
                  <div style={{ fontSize:16, fontWeight:800, color:col }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab==='review' && (
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {questions.map((q,i)=>{
              const opts = safeParseArray(q.options);
              const correct = safeParseArray(q.correct_answers).map(c=>c.toLowerCase().trim());
              const userAns = answers[q.id];
              const isOk = userAns && correct.includes(userAns.toLowerCase().trim());
              return (
                <div key={q.id} style={{ background:'#fff', border:`1.5px solid ${isOk?'#86EFAC':userAns?'#FCA5A5':'#E2E8F0'}`, borderRadius:12, padding:'16px 18px', boxShadow:'0 1px 4px rgba(0,0,0,0.05)' }}>
                  <div style={{ display:'flex', gap:8, marginBottom:10 }}>
                    <span style={{ fontSize:11, fontWeight:700, padding:'2px 10px', borderRadius:20, background:isOk?'#DCFCE7':userAns?'#FEE2E2':'#F1F5F9', color:isOk?'#16A34A':userAns?'#DC2626':'#64748B' }}>{isOk?'✓ Correct':userAns?'✗ Wrong':'— Skipped'}</span>
                    <span style={{ fontSize:11, color:'#94A3B8' }}>Q{i+1}</span>
                  </div>
                  <div style={{ fontSize:14, fontWeight:600, color:'#1E293B', marginBottom:10, lineHeight:1.6 }}><MathText text={q.question_text} /></div>
                  <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
                    {opts.map((opt,oi)=>{
                      const isCrt = correct.includes(opt.toLowerCase().trim());
                      const isUsr = userAns===opt;
                      return (
                        <div key={oi} style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 12px', borderRadius:8, fontSize:13, background:isCrt?'#F0FDF4':isUsr&&!isCrt?'#FEF2F2':'transparent' }}>
                          <span style={{ fontWeight:800, fontSize:11, color:'#94A3B8', minWidth:14 }}>{LETTERS[oi]}</span>
                          <span style={{ color:isCrt?'#16A34A':isUsr&&!isCrt?'#DC2626':'#374151' }}><MathText text={opt} inline /></span>
                          {isCrt&&<span style={{ marginLeft:'auto' }}>✓</span>}
                          {isUsr&&!isCrt&&<span style={{ marginLeft:'auto' }}>✗</span>}
                        </div>
                      );
                    })}
                  </div>
                  <div style={{ marginTop:10 }}>
                    <ExplanationBox question={q} theme="light" style={{ padding: '10px 14px', fontSize: 12 }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ── ENTRY POINT ───────────────────────────────────────────────
export default function StudyApp() {
  const [phase,  setPhase]  = useState('setup');
  const [config, setConfig] = useState(null);
  const [result, setResult] = useState(null);

  if (phase==='setup')   return <SetupScreen onStart={cfg => { setConfig(cfg); setPhase('exam'); }} />;
  if (phase==='exam')    return <ExamScreen config={config} onFinish={r => { setResult(r); setPhase('results'); }} />;
  if (phase==='results') return <ResultsScreen result={result} config={config} onRetry={()=>setPhase('exam')} onNew={()=>{ setConfig(null); setPhase('setup'); }} />;
  return null;
}
