if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config();
}
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const { initDB } = require('./models/db');
const authRoutes     = require('./routes/auth');
const examRoutes     = require('./routes/exams');
const questionRoutes = require('./routes/questions');
const candidateRoutes = require('./routes/candidates');
const analyticsRoutes = require('./routes/analytics');
const proctorRoutes  = require('./routes/proctor');
const subjectRoutes  = require('./routes/subjects');
const importRoutes   = require('./routes/import');
const importBatchesRoutes = require('./routes/importBatches');
const syllabusRoutes = require('./routes/syllabus');
const textbooksRoutes = require('./routes/textbooks');
const settingsRoutes = require('./routes/settings');
const resultsRoutes   = require('./routes/results');
const aiRoutes        = require('./routes/ai');
const parentRoutes    = require('./routes/parent');
const { initSocket } = require('./socket/socketManager');
const { startAutoAnswerSolver } = require('./services/autoAnswerSolver');
const { startAutoDiagramCropper } = require('./services/autoDiagramCropper');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('./middleware/auth');

const app = express();
const server = http.createServer(app);

// Trust Railway's reverse proxy so req.ip and X-Forwarded-For are read
// correctly. Without this, express-rate-limit v7 throws on every request
// when it detects X-Forwarded-For but doesn't trust the proxy — which is
// exactly what was causing the global 500s on both API routes and static
// assets (CSS/JS returning JSON error bodies instead of file content).
app.set('trust proxy', 1);

const gamificationRoutes = require('./routes/gamification');
const paymentsRoutes = require('./routes/payments');
const { paystackWebhookHandler } = paymentsRoutes;

// ── CORS: allow localhost AND any 192.168.x.x / 10.x.x.x on port 3000 ──
// ── CORS ──────────────────────────────────────────────────────────────
// The production domain is hardcoded here ON PURPOSE. It used to depend
// entirely on process.env.CLIENT_URL being set correctly; when that env var
// is missing (or has a trailing slash, or says www when the browser says
// non-www), EVERY request carrying `Origin: https://examaye.com` is
// rejected — including the browser's own requests for /assets/*.js and
// /assets/*.css, because Vite tags those with `crossorigin`, which makes
// the browser send an Origin header even though they are same-origin.
// A rejected request falls straight through to the global error handler,
// which answers with a JSON body — which is exactly the
// "net::ERR_ABORTED 500" on vendor/ui/index .js and the
// "Refused to apply style ... MIME type ('application/json')" in devtools,
// with the page rendering as a blank white screen.
const PRODUCTION_ORIGINS = [
  'https://examaye.com',
  'https://www.examaye.com',
];

const stripTrailingSlash = (value) => String(value || '').trim().replace(/\/+$/, '');

function isAllowedOrigin(origin) {
  if (!origin) return true; // non-browser / curl requests
  const clean = stripTrailingSlash(origin);

  // The deployed production domain, with and without www.
  if (PRODUCTION_ORIGINS.includes(clean)) return true;

  const allowed = [
    'http://localhost:3000',
    'http://127.0.0.1:3000',
    'http://localhost:5173',
    'http://127.0.0.1:5173',
  ];
  if (allowed.includes(clean)) return true;

  // Still honour CLIENT_URL if it is set (trailing slash tolerated now).
  if (process.env.CLIENT_URL && clean === stripTrailingSlash(process.env.CLIENT_URL)) return true;

  // Any *.up.railway.app domain, as a safety net.
  if (/^https:\/\/[a-z0-9-]+\.up\.railway\.app$/.test(clean)) return true;

  // Any LAN IP on port 3000
  if (/^http:\/\/192\.168\.\d+\.\d+:3000$/.test(clean)) return true;
  if (/^http:\/\/10\.\d+\.\d+\.\d+:3000$/.test(clean))  return true;
  if (/^http:\/\/172\.(1[6-9]|2\d|3[01])\.\d+\.\d+:3000$/.test(clean)) return true;

  return false;
}

const corsOptions = {
  origin: (origin, callback) => {
    if (isAllowedOrigin(origin)) {
      callback(null, true);
    } else {
      console.warn('CORS blocked origin:', origin);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: false,
};

// ── Socket.io ──
const io = new Server(server, {
  cors: {
    origin: (origin, callback) => {
      callback(null, isAllowedOrigin(origin));
    },
    methods: ['GET', 'POST'],
    credentials: false,
  },
  transports: ['polling', 'websocket'],
  pingTimeout: 10000,
  pingInterval: 5000,
});

// ── Middleware ──
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // js.paystack.co is required for the checkout widget itself
        // (window.PaystackPop) — without it here, the script is silently
        // blocked by the browser and "Processing..." spins forever with no
        // visible error except in devtools. frameSrc is needed too since
        // Paystack's checkout renders in an iframe, not just a script tag.
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://js.paystack.co"],
        frameSrc: ["'self'", "https://js.paystack.co", "https://checkout.paystack.com"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://paystack.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
        imgSrc: ["'self'", "data:", "blob:"],
        mediaSrc: ["'self'", "data:", "blob:"],
        connectSrc: ["'self'", "ws:", "wss:", "http:", "https:"]
      }
    },
    crossOriginEmbedderPolicy: false
  })
);
// CORS is applied to the API and uploads only — NOT globally. The frontend
// is served by this same server (same origin), so its own JS/CSS must never
// be able to fail a CORS check and get a JSON error body instead of the
// file. Socket.io does its own CORS (configured above).
app.use('/api', cors(corsOptions));
app.use('/uploads', cors(corsOptions));
app.options('/api/*', cors(corsOptions));

// Paystack's checkout (the bank-transfer/USSD screen especially) has its
// own "copy" buttons next to the account number, reference, etc. — those
// need clipboard-write inside its iframe. Browsers deny the Clipboard API
// to embedded content by default unless the page explicitly grants it via
// this header; without it, clicking Paystack's own copy icon silently
// fails with a "Permissions policy violation" in the console (not
// something Paystack's widget can work around on its own — it depends on
// the embedding page, i.e. us, to allow it).
app.use((req, res, next) => {
  res.setHeader('Permissions-Policy', 'clipboard-write=(self "https://checkout.paystack.com" "https://js.paystack.co"), clipboard-read=(self)');
  next();
});

// Rate limiting
//
// This exists to stop abuse (scraping, brute-forcing, a runaway script) —
// it should never throttle two kinds of perfectly normal, legitimate
// traffic that were both getting caught in it before:
//   1. Staff actively working — reviewing/verifying/publishing a batch of
//      50+ questions one at a time is easily 100+ requests in a few
//      minutes; 500/15min sounds generous until you're the one doing that
//      workflow and every few dozen clicks throws a 429 that LOOKS like
//      your changes are silently failing/reverting (they weren't — the
//      request just never reached the route handler at all).
//   2. Many students behind one IP — this is a school exam platform. A
//      classroom on one shared WiFi connection, or a whole school behind
//      one NAT gateway, all appear as a single IP to this server. A single
//      500-request budget shared across an entire class taking a timed
//      exam simultaneously is nowhere near enough, and would look like the
//      app randomly breaking for everyone at once.
// isStaffRequest peeks at the JWT (if any) without the overhead of full
// route-level auth — this middleware runs before any route's own
// authenticate() call, so req.user isn't populated yet at this point.
function isStaffRequest(req) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return false;
    const decoded = jwt.verify(token, JWT_SECRET);
    return decoded.role === 'admin' || decoded.role === 'superadmin' || decoded.role === 'examiner';
  } catch {
    return false; // missing/expired/invalid token — let the normal limit (and the route's own auth) handle it
  }
}

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 3000, // was 500 — too low for a shared school IP; see comment above
  message: { error: 'Too many requests, please try again later.' },
  skip: (req) => req.ip === '127.0.0.1' || req.ip === '::1' || isStaffRequest(req),
});
app.use('/api/', apiLimiter);

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  message: { error: 'Too many login attempts.' },
});
app.use('/api/auth/', authLimiter);

// Paystack webhook — MUST be registered before express.json() below and
// given the raw request body, not the parsed one. Signature verification
// (see paystackWebhookHandler) is an HMAC over the exact raw bytes Paystack
// sent; verifying against a re-serialized JSON object can silently mismatch
// and either reject genuine webhooks or (worse) accept a forged one if the
// check is loosened to compensate. This is also the *reliable* path for
// activating a subscription — unlike the browser-only /verify call, this
// fires even if the student closes the tab right after paying.
app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), paystackWebhookHandler);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(morgan('combined'));

// Static uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── API Routes ──
app.use('/api/auth',       authRoutes);
app.use('/api/exams',      examRoutes);
app.use('/api/questions',  questionRoutes);
app.use('/api/candidates', candidateRoutes);
app.use('/api/analytics',  analyticsRoutes);
app.use('/api/proctor',    proctorRoutes);
app.use('/api/subjects',   subjectRoutes);
app.use('/api/import',     importRoutes);
// New batch-based staging pipeline (Milestone 3) — mounted separately so the
// existing zip-extract/image-extract routes above are completely untouched.
app.use('/api/import/batches', importBatchesRoutes);
// Exam Preparation Learning System — Exam Body Manager + topic content
app.use('/api/syllabus', syllabusRoutes);
app.use('/api/textbooks', textbooksRoutes);
app.use('/api/settings',   settingsRoutes);
app.use('/api/results',  resultsRoutes);
app.use('/api/ai',       aiRoutes);
app.use('/api/parent',   parentRoutes);
// gamification + payments were previously mounted above, before helmet/cors/
// rate-limiting/body-parsing had run — every POST to either (award XP,
// initialize payment, verify payment) crashed with "Cannot destructure
// property of req.body as it is undefined" before it ever reached its own
// logic. Moved here, after express.json()/urlencoded(), where every other
// POST route already correctly lives.
app.use('/api/gamification', gamificationRoutes);
app.use('/api/payments',   paymentsRoutes);

// Health check — shows server IP so students know what to connect to
app.get('/api/health', (req, res) => {
  const os = require('os');
  const nets = os.networkInterfaces();
  const ips = [];
  for (const iface of Object.values(nets)) {
    for (const net of iface) {
      if (net.family === 'IPv4' && !net.internal) {
        ips.push(net.address);
      }
    }
  }
  res.json({
    status: 'ok',
    version: '1.0.0',
    uptime: Math.floor(process.uptime()),
    server_ips: ips,
    student_url: ips.map(ip => `http://${ip}:3000`),
    timestamp: new Date().toISOString(),
  });
});

// ── Serve the built React app in production ──
// Keeps this to one deployed service (cheaper on Railway) instead of hosting
// the frontend separately. Anything not matched by an API route above falls
// through to index.html so React Router can handle client-side routes.
if (process.env.NODE_ENV === 'production') {
  const clientDist = path.join(__dirname, '..', 'client', 'dist');
  app.use(express.static(clientDist));
  app.get(/^(?!\/api|\/uploads|\/socket\.io).*/, (req, res) => {
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);

  // A blocked origin is a 403, not a 500 — it should never be able to
  // masquerade as a broken server or a corrupt asset.
  if (err && err.message === 'Not allowed by CORS') {
    return res.status(403).json({
      error: 'CORS blocked',
      origin: req.headers.origin || null,
    });
  }

  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
  });
});

// Initialize Socket.io
initSocket(io);

// ── Start ──
const PORT = process.env.PORT || 5000;

async function start() {
  try {
    await initDB();
    console.log('✅ Database connected');

    server.listen(PORT, '0.0.0.0', () => {
      // Show all network IPs on startup
      const os = require('os');
      const nets = os.networkInterfaces();
      console.log(`🚀 StudyNavo Server running on port ${PORT}`);
      console.log(`📡 Socket.io ready`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`\n📌 Student access URLs (share with students):`);
      for (const ifaces of Object.values(nets)) {
        for (const iface of ifaces) {
          if (iface.family === 'IPv4' && !iface.internal) {
            console.log(`   http://${iface.address}:3000`);
          }
        }
      }
      console.log('');
    });

    // Fully automatic — no admin action needed. Continuously works through
    // any live question missing a recorded correct answer in the
    // background (see services/autoAnswerSolver.js). The manual "Fix
    // Missing Correct Answers" button in Question Bank still exists for an
    // admin who wants a specific batch done right now, but this covers the
    // rest of the bank on its own over time.
    startAutoAnswerSolver();

    // Same idea, for diagrams: continuously finds live questions missing a
    // diagram image that plausibly need one, and crops one automatically
    // from the archived original source page (see
    // services/autoDiagramCropper.js). A freshly-cropped, correctly-framed
    // diagram is also what lets the answer-solver above actually read and
    // solve a question it previously couldn't.
    startAutoDiagramCropper();
  } catch (err) {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  }
}

start();

module.exports = { app, io };
